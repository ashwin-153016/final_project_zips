package merchantValidation;

import cucumber.api.java.en.Given;
import cucumber.api.java.en.Then;
import cucumber.api.java.en.When;

public class StepDef {

	@Given("^The validation dashboard is loaded$")
	public void the_validation_dashboard_is_loaded() throws Throwable {
	    
	}

	@When("^The newly registered merchant data is loaded$")
	public void the_newly_registered_merchant_data_is_loaded() throws Throwable {
	   
	}

	@Then("^The admin can review the data$")
	public void the_admin_can_review_the_data() throws Throwable {
	   
	}

	@When("^The merchant data loaded is not confronting to the rules$")
	public void the_merchant_data_loaded_is_not_confronting_to_the_rules() throws Throwable {
	   
	}

	@Then("^The admin can decline the merchant's registration$")
	public void the_admin_can_decline_the_merchant_s_registration() throws Throwable {
	   
	}

	@Then("^The merchant data should be removed from the merchant table$")
	public void the_merchant_data_should_be_removed_from_the_merchant_table() throws Throwable {
	    
	}

	@When("^The merchant data loaded confronts to the rules$")
	public void the_merchant_data_loaded_confronts_to_the_rules() throws Throwable {
	    
	}

	@Then("^The admin can approve the merchant's registration$")
	public void the_admin_can_approve_the_merchant_s_registration() throws Throwable {
	    
	}

	@Then("^The isActive field in merchant table should be set to true$")
	public void the_isActive_field_in_merchant_table_should_be_set_to_true() throws Throwable {
	   
	}

}
